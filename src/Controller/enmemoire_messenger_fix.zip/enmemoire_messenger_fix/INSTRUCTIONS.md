# Fix — messenger_messages table introuvable

## Cause
Symfony Messenger tente d'utiliser la base de données comme file d'attente
et cherche la table `messenger_messages` qui n'existe pas.

## Solution 1 — La plus simple (recommandée en dev)
Ajouter le fichier `config/packages/dev/messenger.yaml` fourni dans ce ZIP.
Il force le transport `sync://` en développement : les messages sont traités
immédiatement, sans file d'attente, sans table SQL.

**Copier :**
```
config/packages/dev/messenger.yaml  →  config/packages/dev/messenger.yaml
```

Puis :
```bash
php bin/console cache:clear
```

## Solution 2 — Créer la table messenger_messages
Si vous voulez garder le transport Doctrine, exécutez :

```bash
php bin/console messenger:setup-transports
```

Cette commande crée automatiquement la table `messenger_messages`.

## Vérification
Après correction, réessayez de créer un compte.
L'inscription devrait fonctionner et vous rediriger vers la page OTP.
